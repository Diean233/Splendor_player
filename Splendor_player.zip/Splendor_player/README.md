# Splendor_player

202 algorithm project
https://docs.google.com/document/d/1oSEHkNwIRa-wkR9-Maiu2wru8gZhRkIE1be-o8ckatc/edit?usp=sharing
